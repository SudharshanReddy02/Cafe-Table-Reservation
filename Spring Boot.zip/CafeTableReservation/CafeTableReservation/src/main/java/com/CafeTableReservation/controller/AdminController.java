package com.CafeTableReservation.controller;

import java.util.List;

import org.springframework.http.MediaType;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;

import com.CafeTableReservation.model.Admin;
import com.CafeTableReservation.service.AdminService;



@CrossOrigin(origins = "http://localhost:4200")

@RestController

@RequestMapping("/admin")

public class AdminController {

   private final AdminService adminService;
  

    @Autowired

    public AdminController(AdminService adminService) {

     this.adminService = adminService;

    }
    
    
    
    
    
    
    
    @PostMapping
    public ResponseEntity<Admin> createAdmin(@RequestBody Admin admin) {
        Admin savedAdmin = adminService.save(admin);
        return ResponseEntity.ok(savedAdmin);
    }
    
    
  
  
  
  @PostMapping("/login")

  public ResponseEntity<String> login(@RequestBody Admin adminUser) {

    String email = adminUser.getEmail();

    String password = adminUser.getPassword();

    Admin admin = adminService.findByEmail(email);

    if (admin == null) {

      return ResponseEntity.badRequest().body("Admin not found.");

    }

    if (admin == null ){

      return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");

    }

    return ResponseEntity.ok()
            .contentType(MediaType.TEXT_PLAIN)  // Correct way to set content type
            .body("Login successful");
  }
  
 

  @PutMapping("/updatePassword")
  public ResponseEntity<String> updatePassword(@RequestParam("email") String email, @RequestBody String newPassword) {
      try {
          Admin admin = adminService.findByEmail(email);
          if (admin == null) {
              return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Admin not found.");
          }

          admin.setPassword(newPassword); // Consider hashing the password
          adminService.save(admin);
          return ResponseEntity.ok("Password updated successfully.");
      } catch (Exception e) {
          return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An error occurred: " + e.getMessage());
      }
  }


  
  

}