 package com.CafeTableReservation.controller;




import java.util.List;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.CafeTableReservation.email_request.EmailRequest;
import com.CafeTableReservation.model.User;
import com.CafeTableReservation.service.Users_Service;
 

@CrossOrigin(origins ="http://localhost:4200")
@RestController
@RequestMapping("/api/v1/user-s")
public class UserController {
    private final Users_Service userService;
 
    @Autowired
    public UserController(Users_Service userService) {
        this.userService = userService;
    }
 
    @PostMapping
    public User createUser(@RequestBody User user) {
        user.setStatus("pending");
        return userService.saveUser(user);
    }
    
    
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteUser(@PathVariable Long id) {
        try {
            userService.deleteUserById(id);
            return new ResponseEntity<>("User deleted successfully", HttpStatus.OK);
        } catch (EmptyResultDataAccessException ex) {
            return new ResponseEntity<>("User not found", HttpStatus.NOT_FOUND);
        }
    }
    @GetMapping
    public List<User> getAllUsers() {
        return userService.getAllUsers();
        
    }
    @PutMapping("/{userId}/status")
    public void updateStatus(@PathVariable long userId, @RequestParam String newStatus) {
        userService.updateStatus(userId, newStatus);
    }
 
    @PutMapping("/{userId}/confirm")
    public void confirmUser(@PathVariable long userId) {
        userService.confirmUser(userId);
    }
 
    @PutMapping("/{userId}/deny")
    public void denyUser(@PathVariable long userId) {
        userService.cancelUser(userId);
    }
    
   
 
    @GetMapping("/confirmed-reservations")
    public List<User> getConfirmedReservations() {
        return userService.getConfirmedReservations();
    }
    
    //--------------------------------------------
    
    
    @PostMapping("/send")
    public String sendEmail(@RequestBody EmailRequest emailRequest) {
    	userService.sendSimpleMessage(emailRequest.getTo(), emailRequest.getSubject(), emailRequest.getText());
        return "Email sent successfully!";
    }
    //-------============================================
    
    
    
    
    
    
    
    @GetMapping("/by-email/check")
    public List<User> getUsersByEmail(@RequestParam String email) {
    	
        return userService.getUsersByEmail(email);
    }

    //==========================================
    
    
    
    
    //---------------------------------------------------
    
    
    
//    @GetMapping("/email/{email}")
//    public ResponseEntity<User> getUserByEmail(@PathVariable String email) {
//        User user = userService.getUserByEmail(email);
//        if (user != null) {
//            return new ResponseEntity<>(user, HttpStatus.OK);
//        } else {
//            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
//        }
//    }
    
}
