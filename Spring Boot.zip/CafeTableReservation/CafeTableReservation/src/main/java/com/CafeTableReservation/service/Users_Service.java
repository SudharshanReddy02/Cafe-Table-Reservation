package com.CafeTableReservation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.CafeTableReservation.model.User;
import com.CafeTableReservation.repo.UserRepo;

import jakarta.persistence.EntityNotFoundException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;

@Service
public class Users_Service {
    
    
 
    @Autowired
    private  UserRepo userRepository;
    
    //---------------------------------
 
    @Autowired
    private JavaMailSender emailSender;
    
    
    
    
    //================================
    
    
    public List<User> getUsersByEmail(String email) {
    	
        return  userRepository.findByEmail(email);
    }

    //=====================================
    
    public User saveUser(User user) {
        return userRepository.save(user);
    }
    public void deleteUserById(long id) {
        userRepository.deleteById(id);
    }
    public List<User> getAllUsers() {
        
        return userRepository.findAll();
    }
    public void updateStatus(long userId, String newStatus) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new EntityNotFoundException("User not found with ID: " + userId));
 
        if ("pending".equalsIgnoreCase(newStatus)) {
            // Set the status to "pending"
            user.setStatus("pending");
        } else {
            user.setStatus(newStatus);
        }
        userRepository.save(user);
    }
   
 
   
    public void confirmUser(long userId) {
        updateStatus(userId, "Confirmed");
        
    }
 
   
    public void cancelUser(long userId) {
        updateStatus(userId, "Cancelled");
    }
    public User getUserById(long id) {
        return userRepository.findById(id).orElse(null);
    }
 
  
    public List<User> getConfirmedReservations() {
        return userRepository.findByStatusIgnoreCase("Confirmed");
    }
    
    
    
    
    public void sendSimpleMessage(String to, String subject, String text) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(to);
        message.setSubject(subject);
        message.setText(text);
        emailSender.send(message);
    }
    
    
    
    //==================================================
    
//    public User getUserByEmail(String email) {
//        return userRepository.findByEmail(email);
//    }
//    
    
    
}
