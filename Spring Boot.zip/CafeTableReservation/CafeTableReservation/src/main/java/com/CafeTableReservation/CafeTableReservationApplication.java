package com.CafeTableReservation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CafeTableReservationApplication {

	public static void main(String[] args) {
		SpringApplication.run(CafeTableReservationApplication.class, args);
	}

}
