package com.CafeTableReservation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.CafeTableReservation.model.UserModel;
import com.CafeTableReservation.service.UserService;

import java.util.List;

@RestController
@RequestMapping("/api/v1/")
@CrossOrigin("http://localhost:4200")
public class UserModelController {

    @Autowired
    private UserService userService;

    @GetMapping("/users")
    public List<UserModel> getAllUsers() {
        return userService.getAllUsers();
    }

    @PostMapping("/users")
    public ResponseEntity<UserModel> createUser(@RequestBody UserModel user) {
        UserModel savedUser = userService.createUser(user);
        return ResponseEntity.ok(savedUser);
    }

    @PostMapping("/login")
    public ResponseEntity<String> loginUser(@RequestBody UserModel loginRequest) {
        return userService.loginUser(loginRequest);
    }
    


    @PutMapping("/users/{emailId}")
    public ResponseEntity<UserModel> updateUserProfile(@PathVariable String emailId, @RequestBody UserModel user) {
        UserModel updatedUser = userService.updateUserProfile(emailId, user);
        System.out.println("hello...");
        return ResponseEntity.ok(updatedUser);
        
    }
    


    @GetMapping("/users/email/{email}")
    public ResponseEntity<UserModel> getUserByEmail(@PathVariable String email) {
        UserModel user = userService.getUserByEmail(email);
        return ResponseEntity.ok(user);
    }

    @PutMapping("/users/email/{email}/changepassword")
    public ResponseEntity<String> changeUserPassword(@PathVariable String email, @RequestBody String newPassword) {
        return userService.changeUserPassword(email, newPassword);
    }


    
//    @GetMapping("/users/{emailId}")
//    public ResponseEntity<UserModel> getUserById(@PathVariable String emailId) {
//        UserModel user = userService.getUserById(emailId);
//        return ResponseEntity.ok(user);
//    }

    @GetMapping("/users/email/exists")
    public ResponseEntity<String> checkEmailExists(@RequestParam String email) {
        return userService.checkEmailExists(email);
    }
    
    
    

}