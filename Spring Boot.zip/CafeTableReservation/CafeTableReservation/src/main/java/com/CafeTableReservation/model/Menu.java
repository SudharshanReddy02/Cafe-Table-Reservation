package com.CafeTableReservation.model;
import jakarta.persistence.*;
import java.time.LocalDateTime;
 
import com.fasterxml.jackson.annotation.JsonFormat;
 
@Entity
@Table(name = "menu")
public class Menu {
 
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
 
    @Column(name = "menu_name", nullable = false)
    private String menuName;
 
    @Column(name = "menu_description")
    private String menuDescription;
 
    @Column(name = "price", nullable = false)
    private Double price;
 
    @Column(name = "menu_category")
    private String menuCategory;
 
    @Column(name = "created_time", updatable = false)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createdTime;
 
    @Column(name = "update_time")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime updateTime;
    @PrePersist
    protected void onCreate() {
        createdTime = LocalDateTime.now();
        updateTime = LocalDateTime.now();
    }
 
    @PreUpdate
    protected void onUpdate() {
        updateTime = LocalDateTime.now();
    }
 
	public Long getId() {
		return id;
	}
 
	public void setId(Long id) {
		this.id = id;
	}
 
	public String getMenuName() {
		return menuName;
	}
 
	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}
 
	public String getMenuDescription() {
		return menuDescription;
	}
 
	public void setMenuDescription(String menuDescription) {
		this.menuDescription = menuDescription;
	}
 
	public Double getPrice() {
		return price;
	}
 
	public void setPrice(Double price) {
		this.price = price;
	}
 
	public String getMenuCategory() {
		return menuCategory;
	}
 
	public void setMenuCategory(String menuCategory) {
		this.menuCategory = menuCategory;
	}
 
	public LocalDateTime getCreatedTime() {
		return createdTime;
	}
 
	public void setCreatedTime(LocalDateTime createdTime) {
		this.createdTime = createdTime;
	}
 
	public LocalDateTime getUpdateTime() {
		return updateTime;
	}
 
	public void setUpdateTime(LocalDateTime updateTime) {
		this.updateTime = updateTime;
	}
 
    // Getters and Setters
}