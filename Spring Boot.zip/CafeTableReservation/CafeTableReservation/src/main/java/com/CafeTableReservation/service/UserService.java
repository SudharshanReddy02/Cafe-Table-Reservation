package com.CafeTableReservation.service;

import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.CafeTableReservation.exception.ResourceNotFoundException;
import com.CafeTableReservation.model.UserModel;
import com.CafeTableReservation.repo.UserRepository;

import java.util.List;
import java.util.Optional;

//---------------------------------------
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;

import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;


@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    
    //------------------------------------------
    
 
    //---------------------------------------
    public List<UserModel> getAllUsers() {
        return userRepository.findAll();
    }

    public UserModel createUser(UserModel user) {
        return userRepository.save(user);
    }

    public ResponseEntity<String> loginUser(UserModel loginRequest) {
        UserModel user = userRepository.findByEmailId(loginRequest.getEmailId());
        if (user == null || !user.getPassword().equals(loginRequest.getPassword())) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
        }
        return ResponseEntity.ok("Login successful");
    }

    
  
    
    

    
    public UserModel updateUserProfile(String emailId, UserModel user) {
        // Check if user with given emailId exists
        if (userRepository.existsById(emailId)) {
            user.setEmailId(emailId); // Ensure the emailId is set correctly
            return userRepository.save(user); // Update user
        } else {
            throw new EntityNotFoundException("User with emailId " + emailId + " not found");
        }
    }
    
    
    
    
    //=====================================
    
    


    public UserModel getUserByEmail(String email) {
        UserModel user = userRepository.findByEmailId(email);
        if (user == null) {
            throw new ResourceNotFoundException("User not found with email: " + email);
        }
        return user;
    }
    
    


    public ResponseEntity<String> changeUserPassword(String email, String newPassword) {
        UserModel existingUser = userRepository.findByEmailId(email);
        if (existingUser == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found with email: " + email);
        }

        existingUser.setPassword(newPassword);
        userRepository.save(existingUser);

        return ResponseEntity.ok("Password changed successfully.");
    }

    
    

    


    public ResponseEntity<String> checkEmailExists(String email) {
        boolean exists = userRepository.existsByEmailId(email);
        if (exists) {
            return ResponseEntity.ok("Email exists");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Email does not exist");
        }
    }

    
    
    
    
//	public UserModel getUserById(String emailId) {
//		
//		return null;
//	}
    
    

    

    
    
    
}