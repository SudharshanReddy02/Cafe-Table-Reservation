package com.CafeTableReservation.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;
//------------------------------------------
import java.util.Optional;

import com.CafeTableReservation.model.UserModel;


@Repository
public interface UserRepository extends JpaRepository<UserModel, String> {

 
    UserModel findByEmailId(String emailId);

  
    boolean existsByEmailId(String emailId);
}
