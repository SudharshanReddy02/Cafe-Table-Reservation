package com.CafeTableReservation.repo;

 
import java.util.List;
 
import org.springframework.data.jpa.repository.JpaRepository;

import com.CafeTableReservation.model.User;
 
public interface UserRepo extends JpaRepository<User, Long> {
 
    List<User> findByStatusIgnoreCase(String string);
    
   List<User> findByEmail(String email);
    
  //  User findByEmail(String email);
   

    
   
    
}
