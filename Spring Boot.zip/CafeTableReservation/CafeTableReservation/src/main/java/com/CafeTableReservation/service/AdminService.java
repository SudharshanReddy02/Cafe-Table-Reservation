package com.CafeTableReservation.service;

import java.util.List;

import com.CafeTableReservation.model.Admin;

public interface AdminService{
	Admin findByEmail(String email);

	Admin save(Admin admin);
	
}