package com.CafeTableReservation.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.CafeTableReservation.model.Menu;
import com.CafeTableReservation.repo.MenuRepository;

import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;
@Service
public class MenuService {
 
    @Autowired
    private MenuRepository menuRepository;
 
    public Menu saveMenu(Menu menu) {
        return menuRepository.save(menu);
    }
 
    public Optional<Menu> getMenuById(Long id) {
        return menuRepository.findById(id);
    }
 
    public void updateMenu(Long id, Menu updatedMenu) {
        Menu menu = menuRepository.findById(id).orElseThrow(() -> new RuntimeException("Menu not found"));
        menu.setMenuName(updatedMenu.getMenuName());
        menu.setMenuDescription(updatedMenu.getMenuDescription());
        menu.setPrice(updatedMenu.getPrice());
        menu.setMenuCategory(updatedMenu.getMenuCategory());
        menuRepository.save(menu);  // This will automatically update the `updateTime` field
    }
 
    public void deleteMenu(Long id) {
        menuRepository.deleteById(id);
    }
    public List<Menu> getAllMenus() {
        return menuRepository.findAll();
    }
    
  //------------------------------
    
    public List<Menu> getMenusByCategory(String category) {
        return menuRepository.findByMenuCategory(category);
    }
    
    
  //------------------------------   
}