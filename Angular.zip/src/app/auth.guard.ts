import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { AuthenticationService } from './authentication.service';  // Import your authentication service
import { EmailStorageServiceService } from './services/email-storage-service.service';
@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {


  constructor(private emailStorageService: EmailStorageServiceService, private router: Router) {}

  canActivate(): boolean {
    if (this.emailStorageService.getEmail()) {
      return true;  // User is authenticated if email is set
    } else {
      this.router.navigate(['/user-login']);  // Redirect to login if not authenticated
      return false;
    }
  }
}
