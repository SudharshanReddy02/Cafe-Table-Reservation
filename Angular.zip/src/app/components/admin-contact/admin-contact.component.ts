import { Component } from '@angular/core';
import { ContactserviceService } from 'src/app/services/contactservice.service';

@Component({
  selector: 'app-admin-contact',
  templateUrl: './admin-contact.component.html',
  styleUrls: ['./admin-contact.component.css']
})
export class AdminContactComponent {
  contactInfo: { email: string; phone: string; address: string } = {
    email: 'admin@example.com',
    phone: '+1234567890',
    address: '123 Admin St, Admin City, AC 12345'
  };

  constructor(private contactService: ContactserviceService) {
   
    this.contactService.contactInfo$.subscribe(info => this.contactInfo = info);
  }

  updateContactInfo(updatedInfo: { email?: string; phone?: string; address?: string }) {
    this.contactService.updateContactInfo(updatedInfo);
  }
}
