import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RegisterTableServiceService } from 'src/app/services/register-table-service.service';
import { EmailStorageServiceService } from 'src/app/services/email-storage-service.service';
import { TableNumberService } from 'src/app/services/table-number.service';
@Component({
  selector: 'app-register-table',
  templateUrl: './register-table.component.html',
  styleUrls: ['./register-table.component.css'],
  styles: [
    `
    :host {
      display: block;
      background-color: #beef00;
    }
    `,
  ],
})
export class RegisterTableComponent implements OnInit {
  // user: any = {};
  // tableNumbers: string[] = [];
  // acRoomTableNumbers = ['101', '102', '103', '104'];
  // nonAcRoomTableNumbers = ['201', '202', '203', '204'];

  user: any = {};
  tableNumbers: string[] = [];
  acRoomTableNumbers: string[] = [];
  nonAcRoomTableNumbers: string[] = [];

  //=====================================

  valid_email: string = '';

  constructor(
    private userService: RegisterTableServiceService,
    private router: Router,
    private emailStorageService: EmailStorageServiceService,
    //------------------------------------
    private tableNumberService: TableNumberService
  ) {}

  ngOnInit(): void {
    this.valid_email = this.emailStorageService.getEmail();
    //--------------------------------------
    this.tableNumberService.acRoomTableNumbers$.subscribe(numbers => this.acRoomTableNumbers = numbers);
    this.tableNumberService.nonAcRoomTableNumbers$.subscribe(numbers => this.nonAcRoomTableNumbers = numbers);

  }

  onTableTypeChange() {
    if (this.user.tableColumn === 'ac') {
      this.tableNumbers = this.acRoomTableNumbers;
    } else if (this.user.tableColumn === 'nonAC') {
      this.tableNumbers = this.nonAcRoomTableNumbers;
    } else {
      this.tableNumbers = [];
    }

    // Reset the table number if the type changes
    this.user.tableNumber = '';
  }

  onTableNumberChange() {
    // Update tableColumn to include both type and number
    this.user.tableColumn = this.getFullTableSelection();
  }

  userRegister(): void {
    // Ensure the tableColumn contains the correct concatenated value
    this.user.tableColumn = this.getFullTableSelection();

    if (this.user.email !== this.valid_email) {
      alert('The email entered does not match the login email.');
      return; // Exit the method if email doesn't match
    }

    if (this.isAllDataFilled()) {
      this.userService.registerUser(this.user).subscribe(
        (response) => {
          alert('Successfully booked!');
          // Optionally, navigate to another page or reset form
          // this.router.navigate(['/success']);
        },
        () => {
          alert('Sorry, booking failed.');
        }
      );
    } else {
      alert('Please fill in all required fields.');
    }
  }

  private isAllDataFilled(): boolean {
    return (
      this.user.name &&
      this.user.email &&
      this.user.tableColumn && // tableColumn should now include tableNumber
      this.user.date &&
      this.user.time
      // Add more conditions for other required fields
    );
  }

  private getFullTableSelection(): string {
    return this.user.tableColumn && this.user.tableNumber
      ? `${this.user.tableColumn}-${this.user.tableNumber}`
      : this.user.tableColumn || '';
  }
}
