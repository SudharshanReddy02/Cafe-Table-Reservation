import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/services/login.service'; 
import { EmailStorageServiceService } from 'src/app/services/email-storage-service.service';

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent {
  emailId: string = '';
  password: string = '';
  response: string = '';

  constructor(private loginService: LoginService, private router: Router,private emailStorageService: EmailStorageServiceService) {}

  
  login() {
    this.loginService.login(this.emailId, this.password)
      .subscribe(
        (response: any) => {
          if (response === 'Login successful') {
            alert("User Login succesfully")
            this.emailStorageService.setEmail(this.emailId);
            this.router.navigate(['/home']);
          } else {
            
            this.response = 'Invalid credentials';
          }
        },
        error => {
          this.response = ' Please check the email or password';
        }
      );

}
}
