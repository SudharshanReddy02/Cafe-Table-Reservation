// menu.component.ts

import { Component, OnInit } from '@angular/core';
import { MenuService } from 'src/app/services/menu.service';
import { Menu } from 'src/app/menu.model';  

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {
  menus: Menu[] = [];

  constructor(private menuService: MenuService) { }

  ngOnInit(): void {
    this.loadMenus(); 
  }
  loadMenus(): void {
    this.menuService.getAllMenus().subscribe({
      next: (menus) => this.menus = menus,
      error: (err) => console.error('Error fetching menus:', err)
    });
  }
  
  loadMenusByCategory(category: string): void {
    this.menuService.getMenusByCategory(category).subscribe({
      next: (menus) => this.menus = menus,
      error: (err) => console.error('Error fetching menus by category:', err)
    });
  }
 
}
