import { Component } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';
@Component({
  selector: 'app-admin-create',
  templateUrl: './admin-create.component.html',
  styleUrls: ['./admin-create.component.css']
})
export class AdminCreateComponent {
  email: string = '';
  password: string = '';

  constructor(private adminService: AuthService) { }

  createAdmin() {
    const newAdmin = {
      email: this.email,
      password: this.password
    };

    this.adminService.createAdmin(newAdmin).subscribe(response => {
      console.log('Admin created:', response);
    }, error => {
      console.error('Error creating admin:', error);
    });
  }
}
