import { Component, OnInit } from '@angular/core';
import { TableNumberService } from 'src/app/services/table-number.service';

@Component({
  selector: 'app-admin-table-control',
  templateUrl: './admin-table-control.component.html',
  styleUrls: ['./admin-table-control.component.css']
})
export class AdminTableControlComponent implements OnInit {
  acRoomTableNumbers: string[] = [];
  nonAcRoomTableNumbers: string[] = [];

  constructor(private tableNumberService: TableNumberService) {}

  ngOnInit(): void {
    this.tableNumberService.acRoomTableNumbers$.subscribe(numbers => this.acRoomTableNumbers = numbers);
    this.tableNumberService.nonAcRoomTableNumbers$.subscribe(numbers => this.nonAcRoomTableNumbers = numbers);
  }

  addAcTableNumber(tableNumber: string) {
    this.tableNumberService.addAcTableNumber(tableNumber);
  }

  removeAcTableNumber(tableNumber: string) {
    this.tableNumberService.removeAcTableNumber(tableNumber);
  }

  addNonAcTableNumber(tableNumber: string) {
    this.tableNumberService.addNonAcTableNumber(tableNumber);
  }

  removeNonAcTableNumber(tableNumber: string) {
    this.tableNumberService.removeNonAcTableNumber(tableNumber);
  }
}
