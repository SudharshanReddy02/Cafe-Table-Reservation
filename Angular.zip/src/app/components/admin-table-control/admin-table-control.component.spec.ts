import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminTableControlComponent } from './admin-table-control.component';

describe('AdminTableControlComponent', () => {
  let component: AdminTableControlComponent;
  let fixture: ComponentFixture<AdminTableControlComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminTableControlComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminTableControlComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
