import { Component } from '@angular/core';
import { DashboardService } from 'src/app/services/dashboard.service';
import { User } from 'src/app/User';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent {
  users: User[] = []; 

  
  reservationsCount: number=0;
  purchasesCount: number=4;
  contactsCount: number=1;
  photosCount: number=6;
 
  constructor(private userService: DashboardService) {
  

  } 

  

  ngOnInit(): void { 

    this.loadUsers(); 

  } 

  

  loadUsers(): void { 

    this.userService.getAllUsers().subscribe(users => { 

      this.users = users; 
      //====================================
    
      this.reservationsCount = this.users.length;
    }); 

  } 

  

  confirmUser(userId: number): void { 

    this.userService.confirmUser(userId).subscribe(() => { 

      this.loadUsers(); 

      //------------------------------
      this.sendEmail();

    }); 

  } 

  

  denyUser(userId: number): void { 

    this.userService.denyUser(userId).subscribe(() => { 

      this.loadUsers(); 

    }); 

  }



//------------------------------------------------------------------

to: string = 'default@example.com';
  subject: string = 'Default Subject';
  text: string = 'Default Email Body';
 
 
  sendEmail(): void {
    const emailRequest = { to: this.to, subject: this.subject, text: this.text };
    this.userService.sendEmail(emailRequest).subscribe(response => {
      alert('Email sent successfully!');
    }, error => {
      alert('Failed to send email.');
    });
  }


}
