import { Component } from '@angular/core';

import { User } from '../register-user/User-model'; 

import { UpdateService } from 'src/app/services/update.service';

@Component({

 selector: 'app-change-password',

 templateUrl: './change-password.component.html',

 styleUrls: ['./change-password.component.css']

})

export class ChangePasswordComponent {

  email: string = ''; // Changed from userId to email
  user: User | undefined;
  newPassword: string = '';

  constructor(private updateService: UpdateService) { }

  // Fetch user details by email
  getUserDetails() {
    console.log(this.email);
    
    if (this.email) {
      this.updateService.getUserByEmail(this.email).subscribe(
        data => {
          this.user = data;
        },
        error => {
          console.error('Error fetching user details', error);
          alert('User does not exist.');
        }
      );
    } else {
      alert('Please enter a valid email.');
    }
  }

  // Change user password by email
  changePassword() {
    if (this.user && this.newPassword) {
      console.log(this.user + " " + this.newPassword);
      
      this.updateService.changeUserPasswordByEmail(this.email, this.newPassword).subscribe(
        response => {
          alert('Password changed successfully.');
          this.newPassword = ''; // Clear the new password input
        },
        error => {
          console.error('Error changing password', error);
          alert('Oops, an error occurred while changing the password.');
        }
      );
    } else {
      alert('Please enter a new password and ensure user details are loaded.');
    }
  }

}