
import { Component } from '@angular/core';
import { MenuService } from 'src/app/services/menu.service';  
import { Router } from '@angular/router';
import { Menu } from 'src/app/menu.model';  
 

@Component({
  selector: 'app-add-item',
  templateUrl: './add-item.component.html',
  styleUrls: ['./add-item.component.css']
})
export class AddItemComponent {
  // item: Menu = new Menu();
  // msg: string = "";
  item: Menu = {
    menuName: '',
    price: 0
  };
  msg: string = "";
  constructor(private itemServ: MenuService, private router: Router) { }
 
   ngOnInit(): void { }
 
  // addNewItem(frm: any) {
  //   if (frm.valid) {
  //     this.itemServ.addItem(this.item).subscribe((data: Menu) => {
  //       console.log(data);
  //       this.router.navigate(['/view-all-items']);
  //     });
  //   } else {
  //     this.msg = "Invalid Form";
  //   }
  // }

  addNewItem(frm: any) {
    if (frm.valid) {
      this.itemServ.addItem(this.item).subscribe({
        next: (data: Menu) => {
          console.log(data);
          this.router.navigate(['/view-all-items']);
        },
        error: (err) => {
          console.error(err);
          this.msg = "Failed to add item";
        }
      });
    } else {
      this.msg = "Invalid Form";
    }
  }
}


