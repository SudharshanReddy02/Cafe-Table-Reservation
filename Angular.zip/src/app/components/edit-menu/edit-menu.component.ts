// edit-menu.component.ts
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { MenuService } from 'src/app/services/menu.service';
import { Menu } from 'src/app/menu.model';

@Component({
  selector: 'app-edit-menu',
  templateUrl: './edit-menu.component.html',
  styleUrls: ['./edit-menu.component.css']
})
export class EditMenuComponent implements OnInit {
  editForm: FormGroup;
  menuId?: number;

  constructor(
    private fb: FormBuilder,
    private menuService: MenuService,
    private route: ActivatedRoute,
    private router: Router
  ) {
    this.editForm = this.fb.group({
      menuName: ['', Validators.required],
      menuDescription: [''],
      price: [0, [Validators.required, Validators.min(0)]],
      menuCategory: [''],
      createdTime: [''],
      updateTime: ['']
    });
  }

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    this.menuId = id ? +id : undefined;
    if (this.menuId) {
      this.loadMenu();
    } else {
      console.error('Invalid or missing menu ID');
      this.router.navigate(['/view-all-items']);
    }
  }

  loadMenu(): void {
    if (this.menuId) {
      this.menuService.getMenuById(this.menuId).subscribe({
        next: (menu) => this.editForm.patchValue(menu),
        error: (err) => console.error('Error fetching menu:', err)
      });
    } else {
      console.error('Menu ID is undefined');
    }
  }

  onSubmit(): void {
    if (this.editForm.valid && this.menuId) {
      const updatedMenu: Menu = {
        ...this.editForm.value,
        id: this.menuId
      };
      this.menuService.updateMenu(updatedMenu).subscribe({
        next: () => this.router.navigate(['/view-all-items']),
        error: (err) => console.error('Error updating menu:', err)
      });
    } else {
      console.error('Form is invalid or menu ID is undefined');
    }
  }
}
