import { Component } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service'; 
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-update-password',
  templateUrl: './update-password.component.html',
  styleUrls: ['./update-password.component.css']
})
export class UpdatePasswordComponent {
  message: string | null = null;

  constructor(private authService: AuthService) {}

  onSubmit(form: NgForm) {
    if (form.valid) {
      const email = form.value.email;
      const newPassword = form.value.newPassword;

      this.authService.updatePassword(email, newPassword).subscribe({
        next: (response) => {
          this.message = response;
          form.reset();
        },
        error: (error) => {
          this.message = 'Error updating password: ' + error.message;
        }
      });
    }
  }
}
