import { Component } from '@angular/core';
import { ContactserviceService } from 'src/app/services/contactservice.service';

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css']
})
export class ContactUsComponent {
  contactInfo: { email: string; phone: string; address: string } = {
    email: '',
    phone: '',
    address: ''
  };

  constructor(private contactService: ContactserviceService) {}

  ngOnInit() {
    // Subscribe to the contactInfo observable to get the latest contact information
    this.contactService.contactInfo$.subscribe(info => this.contactInfo = info);
  }
}
