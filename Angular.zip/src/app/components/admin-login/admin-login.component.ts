import { Component } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service'; 
import { Router } from '@angular/router';
import { AdminStorageService } from 'src/app/admin-storage.service';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent {
  email: string = '';
  password: string = '';
  errorMessage: string = '';

  constructor( private adminStorageService: AdminStorageService,
    private authService: AuthService, private router: Router) { }

  onSubmit(): void {
    this.authService.login({ email: this.email, password: this.password }).subscribe({
      next: (response) => {
        alert('Login successful');
        //-------------------------------------------

        this.adminStorageService.setEmail(this.email); 
        //------------------------------
        console.log(response);
        this.router.navigate(['/admin-panel']);
      },


      
      error: (error) => {
        alert('Login Failed');
        this.errorMessage = error.message || 'An unknown error occurred';
        console.error('Login error:', error);
        
      }
    });
  }
  
}
