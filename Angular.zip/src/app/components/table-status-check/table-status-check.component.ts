import { Component,OnInit } from '@angular/core';
import { User } from 'src/app/User';
import { EmailStorageServiceService } from 'src/app/services/email-storage-service.service';
import { StatusCheckService } from 'src/app/services/status-check.service';
@Component({
  selector: 'app-table-status-check',
  templateUrl: './table-status-check.component.html',
  styleUrls: ['./table-status-check.component.css']
})
export class TableStatusCheckComponent implements OnInit {


  users: User[] = [];
  email: string = '';

  //===================================
  valid_email:string='';

  constructor(private statcheckService: StatusCheckService,
    private emailStorageService: EmailStorageServiceService

  ) { }


  ngOnInit(): void {



    //=================================
    this.valid_email = this.emailStorageService.getEmail(); 
  }

  getUsersByEmail(): void {
//========================================

if(this.valid_email!==this.email){
  alert("email not matched");
  return;
}

    this.statcheckService.getUsersByEmail(this.email).subscribe(
      (data: User[]) => {
        this.users = data;
      },
      error => {
        console.error('Error fetching users by email', error);
      }
    );
  }



}
