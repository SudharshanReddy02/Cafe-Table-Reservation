import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TableStatusCheckComponent } from './table-status-check.component';

describe('TableStatusCheckComponent', () => {
  let component: TableStatusCheckComponent;
  let fixture: ComponentFixture<TableStatusCheckComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TableStatusCheckComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TableStatusCheckComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
