import { Component } from '@angular/core';

import { RegisterService } from 'src/app/services/register.service';

import { User } from './User-model';
import { Observable } from 'rxjs';

@Component({

    selector: 'app-register-user',

    templateUrl: './register-user.component.html',

    styleUrls: ['./register-user.component.css']

})

export class RegisterUserComponent {
    user: User = new User();
    emailExists: boolean | null = null;
  
    constructor(private registerService: RegisterService) { }
  
    userRegister() {
      if (this.user.emailId) {
        this.checkEmailExists(this.user.emailId).subscribe(
          exists => {
            this.emailExists = exists;
            if (!exists) {
              this.registerService.registerUser(this.user).subscribe(
                data => {
                  alert("User is registered successfully");
                },
                error => {
                  console.error('Registration error:', error);
                  alert("Oops, an error occurred during registration");
                }
              );
            } else {
              alert("Email already exists!");
            }
          },
          error => {
            console.error('Email check error:', error);
            alert("Oops, an error occurred while checking email");
          }
        );
      } else {
        alert("Email is required!");
      }
    }
  
    checkEmailExists(email: string): Observable<boolean> {
      return this.registerService.checkEmail(email);
    }

}