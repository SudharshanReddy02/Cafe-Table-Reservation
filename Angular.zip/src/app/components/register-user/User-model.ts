export class User{
    id !: number;
  
    firstName !: string; // Should be string
    lastName !: string;  // Should be string
    emailId !: string;
    phone !: string;
    password !: string;
   
}