
import { Component, OnInit } from '@angular/core';
import { User } from '../register-user/User-model'; 
import { UpdateUserProfileService } from 'src/app/services/update-user-profile.service'; 
 import { EmailStorageServiceService } from 'src/app/services/email-storage-service.service';


@Component({
  selector: 'app-update-user-profile',
  templateUrl: './update-user-profile.component.html',
  styleUrls: ['./update-user-profile.component.css']
})
export class UpdateUserProfileComponent implements OnInit {
  userId!: number;
  user!: User;
  email: string = '';
 
  valid_email:string='';
  constructor(private update_user_profile_Service: UpdateUserProfileService,private emailStorageService: EmailStorageServiceService) { }
 
 

  ngOnInit(): void {
    this.valid_email = this.emailStorageService.getEmail(); 
  console.log( this.valid_email);
  }
  getUserDetails() {
    console.log(this.email);

    if(this.valid_email!==this.email){
      alert("email not matched");
      return;
    }
  
    if (this.email) {
      this.update_user_profile_Service.getUserByEmail(this.email).subscribe(
        data => {
          this.user = data;
        },
        error => {
          console.error('Error fetching user details', error);
          alert('User does not exist.');
        }
      );
    } else {
      alert('Please enter a valid email.');
    }

 
}


 
  updateUser() {
    this.update_user_profile_Service.updateUserProfile(this.user).subscribe(response => {
  
      alert("User is updated succesfully")
    },error=>alert("Oops error occured"));
    
    }
}
