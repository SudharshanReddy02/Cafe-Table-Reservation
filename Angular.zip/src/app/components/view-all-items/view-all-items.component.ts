import { Component, OnInit } from '@angular/core';
import { MenuService } from 'src/app/services/menu.service';
import { Menu } from 'src/app/menu.model'; 
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-all-items',
  templateUrl: './view-all-items.component.html',
  styleUrls: ['./view-all-items.component.css']
})
export class ViewAllItemsComponent implements OnInit  {
 
  menus: Menu[] = [];

  constructor(private menuService: MenuService,private router:Router) { }

  ngOnInit(): void {
    this.loadMenus(); 
  }
  loadMenus(): void {
    this.menuService.getAllMenus().subscribe({
      next: (menus) => this.menus = menus,
      error: (err) => console.error('Error fetching menus:', err)
    });
  }

  editMenu(menu: Menu): void {
    // Navigate to edit page or open a modal for editing
    console.log('Edit menu:', menu);
     this.router.navigate(['/edit', menu.id]);
  }

  deleteMenu(menuId?: number): void {
    if (menuId === undefined) return;
    
    this.menuService.deleteMenu(menuId).subscribe({
      next: () => {
        console.log('Menu deleted successfully');
        this.loadMenus(); // Reload the list after deletion
      },
      error: (err) => console.error('Error deleting menu:', err)
    });
  }


}
