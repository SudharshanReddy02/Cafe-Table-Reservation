import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserLoginComponent } from './components/user-login/user-login.component';
import { AdminLoginComponent } from './components/admin-login/admin-login.component';
import { HomeComponent } from './components/home/home.component';

import { RegisterUserComponent } from './components/register-user/register-user.component';
import { AdminPanelComponent } from './components/admin-panel/admin-panel.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ChangePasswordComponent } from './components/change-password/change-password.component';
import { WelcomeComponent } from './components/welcome/welcome.component';
import { ViewAllItemsComponent } from './components/view-all-items/view-all-items.component';
import { MenuComponent } from './components/menu/menu.component';
import { AboutUsComponent } from './components/about-us/about-us.component';
import { GalleryComponent } from './components/gallery/gallery.component';
import { ContactUsComponent } from './components/contact-us/contact-us.component';

import { UpdatePasswordComponent } from './components/update-password/update-password.component';
import { EditMenuComponent } from './components/edit-menu/edit-menu.component';
import { AddItemComponent } from './components/add-item/add-item.component';
import { RegisterTableComponent } from './components/register-table/register-table.component';
import { UpdateUserProfileComponent } from './components/update-user-profile/update-user-profile.component';
import { AdminContactComponent } from './components/admin-contact/admin-contact.component';
import { AdminTableControlComponent } from './components/admin-table-control/admin-table-control.component';
import { TableStatusCheckComponent } from './components/table-status-check/table-status-check.component';

import { AuthGuard } from './auth.guard';

import { AdminGuard } from './admin.guard'; 
import { AdminCreateComponent } from './components/admin-create/admin-create.component';

const routes: Routes = [
  {path:'',component:AboutUsComponent},
 
  { path: 'user-login', component: UserLoginComponent },

  { path: 'admin-login', component: AdminLoginComponent },
  { path: 'home', component: HomeComponent },

  { path: 'register-user', component: RegisterUserComponent },
  { path: 'admin-panel', component: AdminPanelComponent,canActivate: [AdminGuard] },
  { path: 'admin-panel/dashboard', component: DashboardComponent ,canActivate: [AdminGuard]},
  {path:'view-all-items',component:ViewAllItemsComponent} , 
  {path:'change',component:ChangePasswordComponent},
  {path:'menu',component:MenuComponent},
  {path:'about-us',component:AboutUsComponent},
  {path:'gallery',component:GalleryComponent},
  {path:'contact-us',component:ContactUsComponent},
  {path:'admin-update',component:UpdatePasswordComponent},
 {path:'edit/:id',component:EditMenuComponent,canActivate: [AdminGuard]},
 {path:'add-item',component:AddItemComponent,canActivate: [AdminGuard]},
 {path:'register-table',component:RegisterTableComponent,canActivate: [AuthGuard]},
 {path:'update-user-profile',component:UpdateUserProfileComponent,canActivate: [AuthGuard]},
 {path:'admin-contact',component:AdminContactComponent,canActivate: [AdminGuard]},
 {path:'admin-table-control',component:AdminTableControlComponent,canActivate: [AdminGuard]},
 {path:'table-status',component:TableStatusCheckComponent},
 {path:'create-admin',component:AdminCreateComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
