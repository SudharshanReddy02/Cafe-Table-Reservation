import { TestBed } from '@angular/core/testing';

import { RegisterTableServiceService } from './register-table-service.service';

describe('RegisterTableServiceService', () => {
  let service: RegisterTableServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RegisterTableServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
