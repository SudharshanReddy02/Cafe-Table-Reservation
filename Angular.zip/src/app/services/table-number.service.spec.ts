import { TestBed } from '@angular/core/testing';

import { TableNumberService } from './table-number.service';

describe('TableNumberService', () => {
  let service: TableNumberService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TableNumberService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
