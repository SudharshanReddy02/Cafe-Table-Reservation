import { Injectable } from '@angular/core';
import { User } from '../components/register-user/User-model';
import { HttpClient } from '@angular/common/http';
import { catchError, map, Observable, of, throwError } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class  RegisterService {
 
  baseUrl = "http://localhost:8888/api/v1/users"
  private checkEmailUrl = `${this.baseUrl}/email/exists`;

  constructor(private httpClient: HttpClient) { }

  // Register user method
  registerUser(user: User): Observable<Object> {
    return this.httpClient.post<Object>(`${this.baseUrl}`, user).pipe(
      catchError(error => {
        console.error('Error registering user:', error);
        return throwError(() => new Error('Registration failed'));
      })
    );
  }

  
  checkEmail(email: string): Observable<boolean> {
    return this.httpClient.get<string>(`${this.checkEmailUrl}?email=${encodeURIComponent(email)}`).pipe(
      map(response => response === 'Email exists'),
      catchError(error => {
        console.error('Error checking email:', error);
        return of(false); 
      })
    );
  }
}