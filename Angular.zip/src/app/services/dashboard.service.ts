import { HttpClient } from '@angular/common/http'; 

import { Injectable } from '@angular/core'; 

import { Observable } from 'rxjs'; 

import { User } from '../User';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {
  
  private baseUrl = 'http://localhost:8888/api/v1/user-s'; 

  constructor(private http: HttpClient) { }


  // Method to fetch all users
  getAllUsers(): Observable<User[]> {
    return this.http.get<User[]>(`${this.baseUrl}`);
  }

  // Method to fetch confirmed reservations
  getConfirmedReservations(): Observable<User[]> {
    return this.http.get<User[]>(`${this.baseUrl}/confirmed-reservations`);
  }

  // Method to create a new user
  createUser(user: User): Observable<User> {
    return this.http.post<User>(`${this.baseUrl}`, user);
  }

  // Method to confirm a user
  confirmUser(userId: number): Observable<void> {
    return this.http.put<void>(`${this.baseUrl}/${userId}/confirm`, {});

  }

  // Method to deny a user
  denyUser(userId: number): Observable<void> {
    return this.http.put<void>(`${this.baseUrl}/${userId}/deny`, {});
  }

  // Method to delete a user
  deleteUser(userId: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${userId}`);
  }

  //sending email..........................
 
  sendEmail(emailRequest: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/send`, emailRequest);
  }


  getUserByEmail(email: string): Observable<User> {
    const url = `${this.baseUrl}/email/${email}`;
    return this.http.get<User>(url).pipe(
     
    );
  }


}
