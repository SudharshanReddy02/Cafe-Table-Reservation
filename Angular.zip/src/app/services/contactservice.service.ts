import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ContactserviceService {

  private contactInfoSubject = new BehaviorSubject({
    email: 'admin@example.com',
    phone: '+1234567890',
    address: '123 Admin St, Admin City, AC 12345'
  });

  contactInfo$ = this.contactInfoSubject.asObservable();

  updateContactInfo(updatedInfo: { email?: string; phone?: string; address?: string }) {
    const currentInfo = this.contactInfoSubject.value;
    this.contactInfoSubject.next({ ...currentInfo, ...updatedInfo });
  }
}
