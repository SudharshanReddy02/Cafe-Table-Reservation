import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { Menu } from '../menu.model';   // Adjust the path as necessary

@Injectable({
  providedIn: 'root'
})
export class MenuService {
  private baseUrl = 'http://localhost:8888/api/menus'; // Adjust the URL as necessary

  constructor(private http: HttpClient) { }


  //---------------------

  addItem(menu: Menu): Observable<Menu> {
    return this.http.post<Menu>(`${this.baseUrl}`, menu);
  }
  
  //-------------------------

  getMenuById(menuId: number): Observable<Menu> {
    return this.http.get<Menu>(`${this.baseUrl}/${menuId}`);
  }

  updateMenu(menu: Menu): Observable<void> {
    return this.http.put<void>(`${this.baseUrl}/${menu.id}`, menu);
  }

  deleteMenu(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${id}`).pipe(
      catchError(this.handleError)
    );
  }

  getAllMenus(): Observable<Menu[]> {
    return this.http.get<Menu[]>(this.baseUrl).pipe(
      catchError(this.handleError)
    );
  }

  getMenusByCategory(category: string): Observable<Menu[]> {
    return this.http.get<Menu[]>(this.baseUrl+"/category/"+category).pipe(
   
    );
  }

  
  private handleError(error: HttpErrorResponse) {
    console.error('An error occurred:', error.message);
    return throwError(() => new Error('Something went wrong. Please try again later.'));
  }
}
