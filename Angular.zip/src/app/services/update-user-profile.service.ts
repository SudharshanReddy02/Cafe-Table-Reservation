import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from '../components/register-user/User-model'; 


@Injectable({
  providedIn: 'root'
})
export class UpdateUserProfileService {

  private baseUrl = 'http://localhost:8888/api/v1/users';
 
  constructor(private http: HttpClient) { }
 
  // updateUserProfile(user: User): Observable<any> {
  //   const url = `${this.baseUrl}/${user.id}`; // Assuming `id` is a property of the User object
  //   return this.http.put(url, user, { responseType: 'text' as 'json' });
  // }
 
  updateUserProfile(user: User): Observable<any> {
    console.log("helooo..........")
    const url = `${this.baseUrl}/${user.emailId}`; // Assuming `id` is a property of the User object
     return this.http.put(url, user, { responseType: 'text' as 'json' });
     
   }



  // updateUserProfile(user: User): Observable<User> {
  //   console.log("helooo..........");
  //   const url = `${this.baseUrl}/${user.emailId}`;
  //   return this.http.put<User>(url, user).pipe(
  //     // catchError(error => {
  //     //   console.error('Update failed', error);
  //     //   return throwError(error);
  //     // })
  //   );
  // }
  
   
  getUserByEmail(email: string): Observable<User> {
    const url = `${this.baseUrl}/email/${email}`;
    return this.http.get<User>(url).pipe(
     
    );
  }
 


}
