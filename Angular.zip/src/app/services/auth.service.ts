import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, catchError, throwError } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private baseURL ="http://localhost:8888/admin"; 

 

  constructor(private http: HttpClient) { }




  createAdmin(admin: { email: string; password: string }): Observable<any> {
    return this.http.post(this.baseURL, admin);
  }


  login(credentials: { email: string, password: string }): Observable<string> {
    return this.http.post<string>(`${this.baseURL}/login`, credentials, { responseType: 'text' as 'json' }).pipe(
      catchError(this.handleError) 
    );
  }


  // updatePassword(email: string, newPassword: string): Observable<string> {
  //   return this.http.put<string>(`${this.baseURL}/updatePassword?email=${email}`, newPassword, { responseType: 'text' as 'json' }).pipe(
  //     catchError(this.handleError)
  //   );
  // }

  updatePassword(email: string, newPassword: string): Observable<string> {
    return this.http.put<string>(`${this.baseURL}/updatePassword?email=${email}`, newPassword, { responseType: 'text' as 'json' }).pipe(
      catchError(error => {
        console.error('Update Password Error:', error);
        return throwError('Failed to update password, please try again later.');
      })
    );
  }
  

  private handleError(error: any) {
    let errorMessage = 'An unknown error occurred!';
    if (error.error instanceof ErrorEvent) {
      
      errorMessage = `Error: ${error.error.message}`;
    } else {
     
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(() => new Error(errorMessage));
  }



 



}
