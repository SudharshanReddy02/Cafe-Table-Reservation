import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TableNumberService {
  private acRoomTableNumbersSubject = new BehaviorSubject<string[]>(['101', '102', '103', '104']);
  private nonAcRoomTableNumbersSubject = new BehaviorSubject<string[]>(['201', '202', '203', '204']);

  acRoomTableNumbers$ = this.acRoomTableNumbersSubject.asObservable();
  nonAcRoomTableNumbers$ = this.nonAcRoomTableNumbersSubject.asObservable();

  addAcTableNumber(tableNumber: string) {
    const currentNumbers = this.acRoomTableNumbersSubject.value;
    if (tableNumber && !currentNumbers.includes(tableNumber)) {
      this.acRoomTableNumbersSubject.next([...currentNumbers, tableNumber]);
    }
  }

  removeAcTableNumber(tableNumber: string) {
    const currentNumbers = this.acRoomTableNumbersSubject.value;
    this.acRoomTableNumbersSubject.next(currentNumbers.filter(num => num !== tableNumber));
  }

  addNonAcTableNumber(tableNumber: string) {
    const currentNumbers = this.nonAcRoomTableNumbersSubject.value;
    if (tableNumber && !currentNumbers.includes(tableNumber)) {
      this.nonAcRoomTableNumbersSubject.next([...currentNumbers, tableNumber]);
    }
  }

  removeNonAcTableNumber(tableNumber: string) {
    const currentNumbers = this.nonAcRoomTableNumbersSubject.value;
    this.nonAcRoomTableNumbersSubject.next(currentNumbers.filter(num => num !== tableNumber));
  }
}
