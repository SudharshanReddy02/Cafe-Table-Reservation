import { TestBed } from '@angular/core/testing';

import { EmailStorageServiceService } from './email-storage-service.service';

describe('EmailStorageServiceService', () => {
  let service: EmailStorageServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EmailStorageServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
