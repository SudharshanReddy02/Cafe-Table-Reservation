import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { User } from '../User';  
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})


@Injectable({
  providedIn: 'root'
})
export class RegisterTableServiceService {

    baseUrl = "http://localhost:8888/api/v1/user-s"

   constructor(private httpClient : HttpClient) { }
  
   registerUser(user : User) : Observable<Object>
   {
     console.log(user);
     return this.httpClient.post(`${this.baseUrl}`,user);
   }
 
}
