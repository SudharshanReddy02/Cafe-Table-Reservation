import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from '../User'; 
@Injectable({
  providedIn: 'root'
})
export class StatusCheckService {


  private apiUrl = 'http://localhost:8888/api/v1/user-s/by-email/check';

  constructor(private http: HttpClient) { }

  getUsersByEmail(email: string): Observable<User[]> {
    return this.http.get<User[]>(`${this.apiUrl}?email=${email}`);
  }
}
