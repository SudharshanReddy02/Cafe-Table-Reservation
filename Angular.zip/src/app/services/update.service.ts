import { HttpClient } from '@angular/common/http';

import { Injectable } from '@angular/core';

import { Observable,throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { User } from '../components/register-user/User-model'; 

@Injectable({

 providedIn: 'root'

})

export class UpdateService {

 private baseUrl = 'http://localhost:8888/api/v1/users';
 constructor(private http: HttpClient) { }

  // Get user by email
  getUserByEmail(email: string): Observable<User> {
    const url = `${this.baseUrl}/email/${email}`;
    return this.http.get<User>(url).pipe(
      catchError(this.handleError)
    );
  }

  // Change user password by email
  // changeUserPasswordByEmail(email: string, newPassword: string): Observable<any> {
  //   const url = `${this.baseUrl}/email/${email}/changepassword`;
  //   const body = { password: newPassword };
  //   return this.http.put(url, body, { responseType: 'text' as 'json' }).pipe(
  //     catchError(this.handleError)
  //   );
  // }


  changeUserPasswordByEmail(email: string, newPassword: string): Observable<any> {
    const url = `${this.baseUrl}/email/${email}/changepassword`;
    return this.http.put(url, newPassword, { responseType: 'text' as 'json' }).pipe(
        catchError(this.handleError)
    );
}

  private handleError(error: any) {
    console.error('An error occurred:', error);
    return throwError('Something went wrong; please try again later.');
  }
}

