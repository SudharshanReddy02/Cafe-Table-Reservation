import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AdminStorageService {

  private storageKey = 'adminEmail';  // Key for localStorage

  constructor() { }

  setEmail(email: string): void {
    localStorage.setItem(this.storageKey, email);
  }

  getEmail(): string | null {
    return localStorage.getItem(this.storageKey);
  }

  clearEmail(): void {
    localStorage.removeItem(this.storageKey);
  }
}
