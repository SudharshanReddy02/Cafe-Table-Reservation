import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { AuthenticationService } from './authentication.service';  // Import your authentication service
import { AdminStorageService } from './admin-storage.service';
@Injectable({
  providedIn: 'root'
})
export class AdminGuard implements CanActivate {
  constructor(private adminStorageService: AdminStorageService, private router: Router) {}

  canActivate(): boolean {
    if (this.adminStorageService.getEmail()) {  // Check if email is stored
      return true;
    } else {
      this.router.navigate(['/login']); // Redirect to login if not authenticated
      return false;
    }
  }
}
