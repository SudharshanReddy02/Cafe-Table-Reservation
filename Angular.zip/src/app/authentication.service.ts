import { Injectable } from '@angular/core';
import { EmailStorageServiceService } from './services/email-storage-service.service'; // Import your email storage service

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor(private emailStorageService: EmailStorageServiceService) { }

  isAuthenticated(): boolean {
    return !!this.emailStorageService.getEmail();  // Check if email is set
  }

  // Example method for admin role check (if needed)
  isAdmin(): boolean {
    // Implement your admin logic here
    // This might need an additional property or method to check the user role
    return false; // Placeholder
  }
}
