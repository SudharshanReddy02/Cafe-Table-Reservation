export interface Menu {
    id?: number;
    menuName: string;
    menuDescription?: string;
    price: number;
    menuCategory?: string;
    createdTime?: string;
    updateTime?: string;
  }
  