import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { WelcomeComponent } from './components/welcome/welcome.component';
import { UserLoginComponent } from './components/user-login/user-login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdminLoginComponent } from './components/admin-login/admin-login.component';
import { HttpClientModule } from '@angular/common/http';
import { HomeComponent } from './components/home/home.component';
import { RegisterUserComponent } from './components/register-user/register-user.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { AdminPanelComponent } from './components/admin-panel/admin-panel.component';
import { ChangePasswordComponent } from './components/change-password/change-password.component';
import { ViewAllItemsComponent } from './components/view-all-items/view-all-items.component';
import { MenuComponent } from './components/menu/menu.component';
import { AboutUsComponent } from './components/about-us/about-us.component';
import { GalleryComponent } from './components/gallery/gallery.component';
import { ContactUsComponent } from './components/contact-us/contact-us.component';

import { UpdatePasswordComponent } from './components/update-password/update-password.component';
import { EditMenuComponent } from './components/edit-menu/edit-menu.component';
import { AddItemComponent } from './components/add-item/add-item.component';
import { RegisterTableComponent } from './components/register-table/register-table.component';
import { UpdateUserProfileComponent } from './components/update-user-profile/update-user-profile.component';
import { AdminContactComponent } from './components/admin-contact/admin-contact.component';
import { AdminTableControlComponent } from './components/admin-table-control/admin-table-control.component';
import { TableStatusCheckComponent } from './components/table-status-check/table-status-check.component';
import { AdminCreateComponent } from './components/admin-create/admin-create.component';


@NgModule({
  declarations: [
    AppComponent,
    WelcomeComponent,
    UserLoginComponent,
    AdminLoginComponent,
    HomeComponent,
    RegisterUserComponent,
    DashboardComponent,
    AdminPanelComponent,
    ChangePasswordComponent,
    ViewAllItemsComponent,
    MenuComponent,
    AboutUsComponent,
    GalleryComponent,
    ContactUsComponent,
   
    UpdatePasswordComponent,
    EditMenuComponent,
    AddItemComponent,
    RegisterTableComponent,
    UpdateUserProfileComponent,
    AdminContactComponent,
    AdminTableControlComponent,
    TableStatusCheckComponent,
    AdminCreateComponent,
   
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule,HttpClientModule,ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
